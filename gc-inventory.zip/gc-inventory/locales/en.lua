Locales["en"] = {
	["cash"] = "",
	["black_money"] = " ",
	["player_nearby"] = " ",
	["players_nearby"] = "",
	["openinv_help"] = "",
	["openinv_id"] = "",
	["no_permissions"] = "",
	["no_player"] = "",
	["player_inventory"] = ""
}
