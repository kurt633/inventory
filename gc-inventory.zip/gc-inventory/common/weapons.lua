function isWeapon(name)
    return string.find(name, 'WEAPON_') ~= nil
end


